﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Products : IDatabase
    {
        public void Save()
        {
            Console.WriteLine("商品マスターの商品登録");
        }

        public void A()
        {
        }
    }
}
